package com.example.exe1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText et1,et2,et3;
    TextView tvResult;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1=findViewById(R.id.et1);
        et2=findViewById(R.id.et2);
        et3=findViewById(R.id.et3);
        tvResult=findViewById(R.id.tvResult);
        button=findViewById(R.id.button);

    button.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(et1.getText().toString().length()==0){
                et1.setText("0");
            }
            if(et2.getText().toString().length()==0){
                et2.setText("0");
            }
            if(et3.getText().toString().length()==0){
                et3.setText("0");
            }
            int num1= Integer.parseInt(et1.getText().toString());
            int num2=Integer.parseInt(et2.getText().toString());
            int num3=Integer.parseInt(et3.getText().toString());
            int t=num1*30 + num2*40 + num3*50;
            tvResult.setText("Pay:"+ String.valueOf(t));
        }
    });


    }
}
